<?php
//Cargar entorno de clases en memoria de trabajo
define("RUTA_APP","/JOYERIA/");//define macro
require_once("libs/MySQLdb.php");//retorna conn, gestiona $data,$conn
require_once("libs/Controlador.php");//
require_once("libs/Control.php");
?>